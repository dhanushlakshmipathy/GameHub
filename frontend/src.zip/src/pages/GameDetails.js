import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  getGameById,
  getReviewsByGame,
  getAverageRating,
  createReview,
} from "../api";
import ReviewCard from "../components/ReviewCard";
import StarRating from "../components/StarRating";

export default function GameDetails() {
  const { id } = useParams();
  const [game, setGame] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [averageRating, setAverageRating] = useState(0);
  const [newReview, setNewReview] = useState("");
  const [newRating, setNewRating] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const gameData = await getGameById(id);
        setGame(gameData);

        const reviewData = await getReviewsByGame(id);
        setReviews(reviewData);

        const avgRating = await getAverageRating(id);
        setAverageRating(avgRating);
      } catch (err) {
        console.error("Error fetching game details:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [id]);

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    try {
      await createReview(id, { text: newReview, rating: newRating });
      const updatedReviews = await getReviewsByGame(id);
      setReviews(updatedReviews);

      const avgRating = await getAverageRating(id);
      setAverageRating(avgRating);

      setNewReview("");
      setNewRating(0);
    } catch (err) {
      console.error("Error submitting review:", err);
    }
  };

  if (loading) return <p className="text-center mt-10">Loading...</p>;
  if (!game) return <p className="text-center mt-10">Game not found.</p>;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Game Info */}
      <h1 className="text-3xl font-bold mb-4">{game.title}</h1>
      <img
        src={game.image || "/placeholder.png"}
        alt={game.title}
        className="w-full max-h-96 object-cover rounded-lg mb-4"
      />
      <p className="mb-4">{game.description}</p>
      <p className="font-semibold">Average Rating: {averageRating.toFixed(1)} ⭐</p>

      {/* Reviews Section */}
      <h2 className="text-2xl font-semibold mt-6 mb-4">Reviews</h2>
      {reviews.length > 0 ? (
        reviews.map((review, idx) => <ReviewCard key={idx} review={review} />)
      ) : (
        <p>No reviews yet. Be the first to review!</p>
      )}

      {/* Review Form */}
      <form onSubmit={handleReviewSubmit} className="mt-6 space-y-4">
        <textarea
          className="w-full border rounded p-2"
          rows="3"
          placeholder="Write your review..."
          value={newReview}
          onChange={(e) => setNewReview(e.target.value)}
          required
        />
        <div className="flex items-center space-x-4">
          <StarRating rating={newRating} setRating={setNewRating} />
          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Submit Review
          </button>
        </div>
      </form>
    </div>
  );
}
