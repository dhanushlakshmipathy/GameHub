import { useEffect, useState } from "react";
import { getAllGames } from "../api";
import GameCard from "../components/GameCard";

export default function HomePage() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await getAllGames();
        setGames(res.data || []);
      } catch (e) {
        console.error("Error fetching games:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <p>Loading games...</p>;
  if (!games.length) return <p>No games found.</p>;

  return (
    <section>
      <h1 className="text-2xl font-bold mb-4">All Games</h1>
      <div className="flex flex-wrap gap-3">
        {games.map((g) => (
          <GameCard key={g._id} game={g} />
        ))}
      </div>
    </section>
  );
}
