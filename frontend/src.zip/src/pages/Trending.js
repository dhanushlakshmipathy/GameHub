import { useEffect, useState } from "react";
import { getTrending } from "../api";
import GameCard from "../components/GameCard";

export default function Trending() {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await getTrending();
        setGames(res.data || []);
      } catch (e) {
        console.error("Error fetching trending:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <p>Loading trending games...</p>;
  if (!games.length) return <p>No trending games available.</p>;

  return (
    <section>
      <h1 className="text-2xl font-bold mb-4">Trending</h1>
      <div className="flex flex-wrap gap-3">
        {games.map((g) => (
          <GameCard key={g._id} game={g} />
        ))}
      </div>
    </section>
  );
}
