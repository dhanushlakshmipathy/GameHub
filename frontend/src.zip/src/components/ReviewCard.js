import StarRating from "./StarRating";

export default function ReviewCard({ review }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-white/80">
          by <span className="font-medium">{review?.user?.username || "User"}</span>
        </div>
        <StarRating rating={review.rating} />
      </div>
      {review.comment && (
        <p className="mt-3 text-white/90 leading-relaxed">{review.comment}</p>
      )}
      <div className="mt-2 text-xs text-white/60">
        {new Date(review.createdAt).toLocaleString()}
      </div>
    </div>
  );
}
