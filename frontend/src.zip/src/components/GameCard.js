import { Link } from "react-router-dom";
import StarRating from "./StarRating";

export default function GameCard({ game }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 w-full sm:w-[calc(50%-0.75rem)] lg:w-[calc(33.333%-0.75rem)]">
      <h3 className="text-lg font-semibold">{game.title}</h3>
      <p className="text-sm text-white/70">
        {game.genre} {game.platform ? `• ${game.platform}` : ""}
      </p>

      <div className="mt-2">
        <StarRating rating={game.averageRating || 0} />
        <p className="text-xs text-white/60 mt-1">{game.reviewCount || 0} reviews</p>
      </div>

      <div className="mt-4">
        <Link
          to={`/game/${game._id}`}
          className="inline-block text-sm px-3 py-1 rounded-md bg-white/10 hover:bg-white/20"
        >
          View Details
        </Link>
      </div>
    </div>
  );
}
