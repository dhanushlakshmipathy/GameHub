import { Link, useNavigate, useLocation } from "react-router-dom";
import { useState, useMemo } from "react";

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [query, setQuery] = useState("");

  const token = localStorage.getItem("token");
  const isAuthed = !!token;

  const onLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
    window.location.reload();
  };

  const onSearch = (e) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (!trimmed) return;
    navigate(`/search?query=${encodeURIComponent(trimmed)}`);
    setQuery("");
  };

  const active = useMemo(() => location.pathname, [location]);

  return (
    <header className="bg-[#0a0c10]/90 border-b border-white/10 sticky top-0 z-30 backdrop-blur">
      <nav className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-4">
        <Link to="/" className="font-bold text-xl tracking-wide">
          GameHub<span className="text-[#22d3ee]">d</span>
        </Link>

        <Link
          to="/"
          className={`px-2 py-1 rounded ${active === "/" ? "bg-white/10" : "hover:bg-white/5"}`}
        >
          Home
        </Link>
        <Link
          to="/trending"
          className={`px-2 py-1 rounded ${active.startsWith("/trending") ? "bg-white/10" : "hover:bg-white/5"}`}
        >
          Trending
        </Link>

        <form onSubmit={onSearch} className="ml-auto flex items-center gap-2">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search games..."
            className="h-9 rounded-md px-3 outline-none bg-white text-black"
          />
          <button
            type="submit"
            className="h-9 px-3 rounded-md bg-[#22d3ee] text-black font-medium hover:opacity-90"
          >
            Search
          </button>
        </form>

        {isAuthed ? (
          <>
            <Link
              to="/profile"
              className={`px-3 py-1 rounded ${active.startsWith("/profile") ? "bg-white/10" : "hover:bg-white/5"}`}
            >
              Profile
            </Link>
            <button onClick={onLogout} className="px-3 py-1 rounded hover:bg-white/5">
              Logout
            </button>
          </>
        ) : (
          <>
            <Link
              to="/login"
              className={`px-3 py-1 rounded ${active.startsWith("/login") ? "bg-white/10" : "hover:bg-white/5"}`}
            >
              Login
            </Link>
            <Link
              to="/register"
              className={`px-3 py-1 rounded ${active.startsWith("/register") ? "bg-white/10" : "hover:bg-white/5"}`}
            >
              Register
            </Link>
          </>
        )}
      </nav>
    </header>
  );
}
