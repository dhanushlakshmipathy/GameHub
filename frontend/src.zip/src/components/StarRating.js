export default function StarRating({ rating = 0 }) {
  // rating can be number (e.g., 3.7). We’ll fill floor(rating)
  const full = Math.floor(Number(rating) || 0);
  const items = Array.from({ length: 5 });

  return (
    <div aria-label={`Rating ${rating} out of 5`} className="select-none">
      {items.map((_, i) => (
        <span key={i} className="text-yellow-400 text-lg">
          {i < full ? "★" : "☆"}
        </span>
      ))}
      <span className="ml-2 text-sm text-white/70 align-middle">
        {Number(rating || 0).toFixed(1)}
      </span>
    </div>
  );
}
